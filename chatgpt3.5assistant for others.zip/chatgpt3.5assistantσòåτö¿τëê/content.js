console.log("ChatGPT 3.5 Assistant content script loaded.");
